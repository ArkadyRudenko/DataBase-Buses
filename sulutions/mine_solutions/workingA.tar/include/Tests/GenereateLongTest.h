#pragma once
#include <sstream>
void GenerateStops(std::stringstream &file);
void Generate(std::stringstream &file);
void GenerateReq(std::stringstream& file);