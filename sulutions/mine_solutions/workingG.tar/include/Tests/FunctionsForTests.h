#pragma once

#include <sstream>

std::string RemoveSpaces(std::stringstream& ss);

std::string GoBaseBuses(std::stringstream& input);