//
// Created by arkady on 03.02.2022.
//

#ifndef BASEBUSES_ALLRESOURCES_H
#define BASEBUSES_ALLRESOURCES_H

#include "test1.h"
#include "test2.h"
#include "test3.h"
#include "test1_exp.h"
#include "test2_exp.h"
#include "test3_exp.h"

#endif //BASEBUSES_ALLRESOURCES_H
