void JsonSimpleTest();
void JsonArrayTest();

void JsonArrayTestN();

void JsonAccessTest();

void JsonBigTest();

void JsonPrintTest();
void JsonDoubleTest();

void TestJsonAll();