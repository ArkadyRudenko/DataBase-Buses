#include <iostream>
#include <ranges>
#include <algorithm>
#include <unordered_map>

#include "BaseBusesBuilder.h"
#include "BaseBusesProcess.h"
#include "Tests.h"

using namespace std;


int main() {
//    TestAll();
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    BaseBuses baseBuses = BaseBusesBuilder().BuildBase();
    BaseBusesProcess(baseBuses);
//    unordered_map<string, int> m;
//    m.insert({"a", 1000});
//    m.insert({"a", 50});
//    for(auto a : m) {
//        cout << a.second;
//    }
    return 0;
}