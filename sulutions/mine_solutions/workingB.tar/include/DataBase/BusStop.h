#pragma once

#include <string>

struct BusStop {
    std::string name;
    double latitude;
    double longitude;
};
