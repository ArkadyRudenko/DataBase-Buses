//
// Created by arkady on 03.02.2022.
//

#ifndef BASEBUSES_TEST1_EXP_H
#define BASEBUSES_TEST1_EXP_H

stringstream LoadTest1Exp() {
    std::stringstream ss;
    ss << R"([
{ "curvature": 1.42963,"request_id": 1,"route_length": 5990,"stop_count": 4,"unique_stop_count": 3},
{ "curvature": 1.30156,"request_id": 2,"route_length": 11570,"stop_count": 5,"unique_stop_count": 3},
{ "buses": ["297","635"],"request_id": 3},
{ "items": [{ "stop_name": "Biryulyovo Zapadnoye","time": 6,"type": "Wait"},{ "bus": "297","span_count": 2,"time": 5.235,"type": "Bus"}],"request_id": 4,"total_time": 11.235},
{ "items": [{ "stop_name": "Biryulyovo Zapadnoye","time": 6,"type": "Wait"},{ "bus": "297","span_count": 2,"time": 5.235,"type": "Bus"},{ "stop_name": "Universam","time": 6,"type": "Wait"},{ "bus": "635","span_count": 1,"time": 6.975,"type": "Bus"}],"request_id": 5,"total_time": 24.21}
])";
    return ss;
}

#endif //BASEBUSES_TEST1_EXP_H
