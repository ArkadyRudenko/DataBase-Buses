#pragma once

void TestAll();